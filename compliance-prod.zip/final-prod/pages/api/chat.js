import { checkRateLimit } from "../../lib/rateLimiter";
import { validateMessages } from "../../lib/validate";

const SYSTEM_PROMPT = `Tu es l'agent 'Compliance-Data-2026'. Ta mission est d'aider les Directions Financières françaises à nettoyer leur base de données fournisseurs pour la réforme de la facturation électronique.

IMPORTANT : Les noms des entreprises ont été remplacés par des codes anonymes (FOURN_001, etc.) pour protéger les données confidentielles.

### 1. TON EXPERTISE TECHNIQUE
* SIRET : Tu vérifies que le numéro possède 14 chiffres et respecte l'algorithme de Luhn.
* TVA Intracommunautaire : Tu vérifies le format (FR + 11 chiffres). Tu sais calculer la clé de TVA à partir du SIREN si elle est manquante (Clé = [12 + 3 * (SIREN mod 97)] mod 97).
* Dénomination Sociale : Tu identifies les correspondances entre noms commerciaux et raisons sociales officielles.

### 2. TA MÉTHODOLOGIE DE TRAVAIL
1. Analyser la cohérence des données reçues.
2. Diagnostiquer l'erreur (SIRET fermé, TVA mal formatée, doublons).
3. Remédier en proposant la donnée corrigée.

### 3. FORMAT DE SORTIE (IMPÉRATIF)
Réponds TOUJOURS sous forme de tableau Markdown :
| Code Fournisseur | Statut | Type d'erreur | SIRET Corrigé | TVA Corrigée | Fiabilité (%) |

Puis un résumé chiffré (nb erreurs, nb valides, nb à vérifier).

### 4. ATTITUDE
Précis, rigoureux, professionnel. Si doute : 'À VÉRIFIER MANUELLEMENT'.`;

function getClientIp(req) {
  return req.headers["x-forwarded-for"]?.split(",")[0]?.trim() || req.headers["x-real-ip"] || req.socket?.remoteAddress || "unknown";
}

function auditLog(level, ip, details) {
  console.log(JSON.stringify({ ts: new Date().toISOString(), level, ip: ip.replace(/\.\d+$/, ".xxx"), ...details }));
}

export default async function handler(req, res) {
  const ip = getClientIp(req);
  if (req.method !== "POST") return res.status(405).json({ error: "Méthode non autorisée" });

  const rateCheck = await checkRateLimit(ip);
  if (!rateCheck.allowed) {
    auditLog("WARN", ip, { event: "rate_limited" });
    res.setHeader("Retry-After", rateCheck.retryAfter);
    return res.status(429).json({ error: rateCheck.message });
  }

  const { messages } = req.body || {};
  const validation = validateMessages(messages);
  if (!validation.valid) {
    auditLog("WARN", ip, { event: "validation_failed", reason: validation.error });
    return res.status(400).json({ error: validation.error });
  }

  if (!process.env.ANTHROPIC_API_KEY) {
    return res.status(500).json({ error: "Configuration serveur manquante. Contactez l'administrateur." });
  }

  auditLog("INFO", ip, { event: "audit_request", msg_count: messages.length });

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 2000, system: SYSTEM_PROMPT, messages }),
    });

    if (!response.ok) {
      auditLog("ERROR", ip, { event: "anthropic_error", status: response.status });
      return res.status(502).json({ error: "Erreur de l'API IA. Réessayez." });
    }

    const data = await response.json();
    const reply = data.content?.map((b) => b.text || "").join("") || "";
    auditLog("INFO", ip, { event: "audit_success" });
    res.setHeader("Cache-Control", "no-store");
    return res.status(200).json({ reply });
  } catch (err) {
    auditLog("ERROR", ip, { event: "server_error", msg: err.message });
    return res.status(500).json({ error: "Erreur serveur interne" });
  }
}
